#!/bin/bash
python server.py 