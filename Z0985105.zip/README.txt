Folder contains the .sh scripts as requested along with 2 .bat scripts. 
If the .sh fail to work (due to using them on windows cmd as opposed to a bash client/linux) then please use the .bat files instead
These will work as long as you have python 3 and above. if not then "python3" must be used in place of "python"